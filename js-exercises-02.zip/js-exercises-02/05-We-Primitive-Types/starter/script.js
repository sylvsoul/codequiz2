let one = 64;
let two = "656302";
let three = false;
let four = 64.55;
let five = "Howdy!";
let six;

// Insert comments to explain what each console.log() statement
// below will log/print to the console
console.log(typeof one);
console.log(typeof two);
console.log(typeof three);
console.log(typeof four);
console.log(typeof five);
console.log(typeof six);

four = "Hello!";
five = false;
six = 23;

// Insert comments to explain what each console.log() statement
// below will log to the console
console.log(typeof four);
console.log(typeof five);
console.log(typeof six);
