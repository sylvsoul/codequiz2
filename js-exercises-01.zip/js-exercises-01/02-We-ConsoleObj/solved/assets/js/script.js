// using javascript code, use the log() method of the console object
// to log the following message to the console:
// "This is the log for the 🔥EXTERNAL🔥JavaScript"

console.log("This is the log for the 🔥EXTERNAL🔥JavaScript");
